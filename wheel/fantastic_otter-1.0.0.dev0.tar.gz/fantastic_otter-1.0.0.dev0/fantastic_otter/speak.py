def say_hello() -> str:
    return "Hello from fantastic_otter!"
